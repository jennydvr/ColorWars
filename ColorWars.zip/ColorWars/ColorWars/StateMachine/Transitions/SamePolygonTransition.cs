﻿namespace ColorWars
{
    class SamePolygonTransition : Transition
    {
        #region Constructor

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="character">Character of the transition</param>
        public SamePolygonTransition(Character character) :
            base(character)
        {
            this.targetState = new PursueState(character);
            this.condition = new SamePolygonCondition(character);
        }

        #endregion
    }
}