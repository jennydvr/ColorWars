﻿namespace ColorWars
{
    class DifferentPolygonTransition : Transition
    {
        #region Constructor

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="character">Character of the transition</param>
        public DifferentPolygonTransition(Character character) :
            base(character)
        {
            this.targetState = new StarState(character);
            this.condition = new NotCondition(character, new SamePolygonCondition(character));
        }

        #endregion
    }
}