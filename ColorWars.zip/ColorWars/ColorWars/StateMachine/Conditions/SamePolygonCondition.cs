﻿using System.Collections.Generic;
using Microsoft.Xna.Framework;

namespace ColorWars
{
    /// <summary>
    /// Checks if the character is in the same polygon of dotty
    /// </summary>
    class SamePolygonCondition : Condition
    {
        #region Methods

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="character">Character</param>
        public SamePolygonCondition(Character character) :
            base(character)
        {
        }

        public override bool test()
        {
            return GetPolygon(character.kinematic).center == GetPolygon(GameMode.dotty.kinematic).center;
        }

        /// <summary>
        /// Finds the polygon of a character
        /// </summary>
        /// <param name="character">Kinematic of the character</param>
        /// <returns>The polygon of the character</returns>
        private Polygon GetPolygon(Kinematic character)
        {
            float min = float.PositiveInfinity;
            Polygon polygon = new Polygon(new List<Vector2>());
            Vector2 vect = new Vector2(character.position.X, character.position.Y);

            foreach (Polygon poly in GameMode.polygons)
            {
                float diff = Vector2.Distance(poly.center, vect);

                if (poly.Contains(vect) && diff < min)
                {
                    min = diff;
                    polygon = poly;
                }
            }

            return polygon;
        }

        #endregion
    }
}