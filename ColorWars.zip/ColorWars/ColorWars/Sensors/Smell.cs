﻿using Microsoft.Xna.Framework;

namespace ColorWars
{
    class Smell : Sensor
    {
        #region Constructor

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="character">Character of this sensor</param>
        public Smell(Character character) :
            base(character)
        {
            this.graph = GameMode.smells;
        }

        #endregion

        #region Sensor Stuff

        public override void Detect()
        {
            Node node = GetNearestNode(character.kinematic);
            Vector3 squorre = character.kinematic.position;

            // Check if the node contains any smell signal
            for (int i = 0; i != node.signals.Count; ++i)
            {
                Signal signal = node.signals[i];

                // If there is, check if there are any particles around us
                if (signal is Scent)
                {
                    for (int j = 0; j != signal.points.Count; ++j)
                    {
                        Particle particle = signal.points[j];
                        float newdiff = (squorre - particle.target.position).Length();

                        // If there is a particle near us, follow its origin
                        if (newdiff <= 200)
                        {
                            if (!activated)
                            {
                                activated = true;
                                origin = particle.origin.Clone();
                            }
                            else if (activated & newdiff < (squorre - origin.position).Length())
                            {
                                origin = particle.origin.Clone();
                            }

                            return;
                        }
                    }
                }

            }
            
            // Else, deactivate the sensor
            activated = false;
        }

        #endregion
    }
}