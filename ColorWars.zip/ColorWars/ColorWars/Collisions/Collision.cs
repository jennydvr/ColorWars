﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;

namespace ColorWars
{
    class Collision
    {
        public Vector3 position = Vector3.Zero;
        public Vector3 normal = Vector3.Zero;
    }
}
